import React from 'react'
import { ServicesTable } from '../components/Table/Services'

export const Services = () => {
  return (
    <div>
        <ServicesTable />
    </div>
  )
}
