import React from 'react'
import { UserTable } from '../components/Table/UserTable '

export const AdminUsers = () => {
  return (
    <div>
        <UserTable />
    </div>
  )
}
