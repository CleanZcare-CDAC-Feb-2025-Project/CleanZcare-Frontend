import React from 'react'
import { IncomeTable } from '../../components/Table/Professional/IncomeTable'


export  function IncomePage() {
  return (
    <div>
      <IncomeTable/>
    </div>
  )
}

export default IncomePage
